#include <cpp_api/navigation_bridge.h>
#include <iostream>

int main(int argc, char *argv[])
{
    Navigation nav;

    
    nav.take_off(5.0);
    //Sending Position Setpoints
    nav.position_set(6.5, 0, -5.0, 0, 1.0, false, true, false, false);
//sends (x,y,z)=(1.0,3.5,-5.0)(m), yaw=0rad, tolerance=1.0m, relative=false, async=true,   yaw_valid=flase, body_frame=false
  
   nav.position_set(6.5, 6.5, -5.0, 0, 1.0, false, true, false, false);
//sends (x,y,z)=(1.0,3.5,-5.0)(m), yaw=0rad, tolerance=1.0m, relative=false, async=true, yaw_valid=false, body_frame=false
    
	nav.position_set(0, 6.5, -5.0, 0, 1.0, false, true, false, false);
//sends (x,y,z)=(1.0,3.5,-5.0)(m), yaw=0rad, tolerance=1.0m, relative=false, async=true, yaw_valid=false, body_frame=false
    
    nav.position_set(4.0, 5.5, -5.0, 0, 1.0, false, true, false, false);
//sends (x,y,z)=(1.0,3.5,-5.0)(m), yaw=0rad, tolerance=1.0m, relative=false, async=true, yaw_valid=false, body_frame=false

    nav.land(false); //Landing
}
